import React from "react";

const QuizCard = ({ title, description, fee, onDetailsClick }) => (
    <div className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <p className="text-purple-600 font-bold mb-4">Fee: ${fee}</p>
        <button
            onClick={onDetailsClick}
            className="btn bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 rounded"
        >
            View Details
        </button>
    </div>
);

export default QuizCard;
