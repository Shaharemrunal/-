import React, { useState } from "react";
import axios from "axios";

const AddQuestions = () => {
    const [title, setTitle] = useState("");
    const [duration, setDuration] = useState("");
    const [questions, setQuestions] = useState([
        { questionText: "", options: ["", "", "", ""], correctAnswer: "" },
    ]);

    const handleQuestionChange = (index, field, value) => {
        const updatedQuestions = [...questions];
        if (field === "options") {
            updatedQuestions[index].options = value;
        } else {
            updatedQuestions[index][field] = value;
        }
        setQuestions(updatedQuestions);
    };

    const addNewQuestion = () => {
        setQuestions([
            ...questions,
            { questionText: "", options: ["", "", "", ""], correctAnswer: "" },
        ]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const payload = { title, duration, questions };
            const response = await axios.post("/api/quizzes", payload, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            alert("Quiz added successfully!");
            console.log(response.data);
        } catch (error) {
            console.error(error);
            alert("Failed to add quiz.");
        }
    };

    return (
        <div className="max-w-4xl mx-auto p-6 bg-white rounded shadow">
            <h1 className="text-2xl font-bold mb-4">Add a New Quiz</h1>
            <form onSubmit={handleSubmit}>
                <div className="mb-4">
                    <label className="block text-gray-700 font-bold">Quiz Title</label>
                    <input
                        type="text"
                        className="w-full border p-2 rounded"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 font-bold">Duration (minutes)</label>
                    <input
                        type="number"
                        className="w-full border p-2 rounded"
                        value={duration}
                        onChange={(e) => setDuration(e.target.value)}
                        required
                    />
                </div>
                {questions.map((question, index) => (
                    <div key={index} className="mb-6">
                        <label className="block text-gray-700 font-bold">
                            Question {index + 1}
                        </label>
                        <input
                            type="text"
                            className="w-full border p-2 rounded mb-2"
                            placeholder="Enter question text"
                            value={question.questionText}
                            onChange={(e) =>
                                handleQuestionChange(index, "questionText", e.target.value)
                            }
                            required
                        />
                        <label className="block text-gray-700 font-bold">Options</label>
                        {question.options.map((option, optIndex) => (
                            <input
                                key={optIndex}
                                type="text"
                                className="w-full border p-2 rounded mb-2"
                                placeholder={`Option ${optIndex + 1}`}
                                value={option}
                                onChange={(e) => {
                                    const updatedOptions = [...question.options];
                                    updatedOptions[optIndex] = e.target.value;
                                    handleQuestionChange(index, "options", updatedOptions);
                                }}
                                required
                            />
                        ))}
                        <label className="block text-gray-700 font-bold">
                            Correct Answer (1-4)
                        </label>
                        <input
                            type="number"
                            className="w-full border p-2 rounded"
                            min="1"
                            max="4"
                            value={question.correctAnswer}
                            onChange={(e) =>
                                handleQuestionChange(index, "correctAnswer", e.target.value)
                            }
                            required
                        />
                    </div>
                ))}
                <button
                    type="button"
                    className="bg-blue-500 text-white px-4 py-2 rounded"
                    onClick={addNewQuestion}
                >
                    Add Another Question
                </button>
                <button
                    type="submit"
                    className="bg-green-500 text-white px-4 py-2 rounded ml-4"
                >
                    Submit Quiz
                </button>
            </form>
        </div>
    );
};

export default AddQuestions;
