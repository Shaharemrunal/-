import React from "react";

const CertificateCard = ({ quizTitle, date, onDownloadClick }) => (
    <div className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
        <h3 className="text-lg font-semibold">{quizTitle}</h3>
        <p className="text-gray-600 mb-4">Issued on: {new Date(date).toLocaleDateString()}</p>
        <button
            onClick={onDownloadClick}
            className="btn bg-green-600 text-white hover:bg-green-700 px-4 py-2 rounded"
        >
            Download Certificate
        </button>
    </div>
);

export default CertificateCard;
