import React from "react";

const Footer = () => (
    <footer className="bg-gray-900 text-white py-6">
        <div className="container mx-auto text-center">
            <p className="mb-2">© 2024 Quizzer. All Rights Reserved.</p>
            <div className="flex justify-center space-x-4">
                <a href="/about" className="hover:text-purple-500">About</a>
                <a href="/terms" className="hover:text-purple-500">Terms & Conditions</a>
                <a href="/privacy" className="hover:text-purple-500">Privacy Policy</a>
                <a href="/contact" className="hover:text-purple-500">Contact</a>
            </div>
        </div>
    </footer>
);

export default Footer;
