import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
    FaBars,
    FaTimes,
    FaHome,
    FaSignInAlt,
    FaUserPlus,
    FaInfoCircle,
    FaEnvelope,
} from "react-icons/fa";
import Q_Logo from "../assets/images/Q_logo.png";

const Navbar = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [loggedIn, setLoggedIn] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    // Check if user is logged in
    useEffect(() => {
        setLoggedIn(!!localStorage.getItem("authToken"));
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("authToken");
        setLoggedIn(false);
    };

    return (
        <nav className="bg-gray-900 text-white">
            <div className="container mx-auto flex justify-between items-center px-4 pt-2">
                <Link to="/" className="flex items-center">

                    <img
                        src={Q_Logo}
                        alt="Logo"
                        className="h-16 w-16 mr-2 rounded-full"
                    />

                    <span style={{ fontFamily: '"Quando", serif', fontWeight: 400 }} className="text-lg font-bold hover:text-gray-400 transition-colors">
                        Quizzer
                    </span>
                </Link>


                <button
                    className="text-2xl sm:hidden focus:outline-none"
                    onClick={toggleMenu}
                >
                    {isMenuOpen ? <FaTimes /> : <FaBars />}
                </button>


                <div
                    className={`absolute top-16 left-0 w-full bg-gray-800 sm:bg-transparent sm:relative sm:top-auto sm:left-auto sm:w-auto sm:flex sm:items-center sm:space-x-6 transition-transform ${isMenuOpen ? "block" : "hidden"
                        }`}
                >

                    <Link
                        to="/home"
                        className="flex items-center px-4 py-2 text-sm sm:px-0 sm:py-0 sm:text-base hover:bg-gray-700 sm:hover:bg-transparent transition-colors"
                    >
                        <FaHome className="sm:hidden mr-2" />
                        <span>Home</span>
                    </Link>


                    {loggedIn ? (
                        <button
                            onClick={handleLogout}
                            className="flex items-center px-4 py-2 text-sm sm:px-0 sm:py-0 sm:text-base hover:bg-gray-700 sm:hover:bg-transparent transition-colors"
                        >
                            <FaSignInAlt className="sm:hidden mr-2" />
                            <span>Logout</span>
                        </button>
                    ) : (
                        <Link
                            to="/login"
                            className="flex items-center px-4 py-2 text-sm sm:px-0 sm:py-0 sm:text-base hover:bg-gray-700 sm:hover:bg-transparent transition-colors"
                        >
                            <FaSignInAlt className="sm:hidden mr-2" />
                            <span>Login</span>
                        </Link>
                    )}


                    <Link
                        to="/register"
                        className="flex items-center px-4 py-2 text-sm sm:px-0 sm:py-0 sm:text-base hover:bg-gray-700 sm:hover:bg-transparent transition-colors"
                    >
                        <FaUserPlus className="sm:hidden mr-2" />
                        <span>Sign Up</span>
                    </Link>


                    <Link
                        to="/about"
                        className="flex items-center px-4 py-2 text-sm sm:px-0 sm:py-0 sm:text-base hover:bg-gray-700 sm:hover:bg-transparent transition-colors"
                    >
                        <FaInfoCircle className="sm:hidden mr-2" />
                        <span>About us</span>
                    </Link>


                    <Link
                        to="/contact"
                        className="flex items-center px-4 py-2 text-sm sm:px-0 sm:py-0 sm:text-base hover:bg-gray-700 sm:hover:bg-transparent transition-colors"
                    >
                        <FaEnvelope className="sm:hidden mr-2" />
                        <span>Contact</span>
                    </Link>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
