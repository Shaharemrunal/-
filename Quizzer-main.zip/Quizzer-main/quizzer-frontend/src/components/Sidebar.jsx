import React from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
    return (
        <aside className="sidebar">
            <ul>
                <li><Link to="/">Dashboard</Link></li>
                <li><Link to="/users">Users</Link></li>
                <li><Link to="/quizzes">Quizzes</Link></li>
                <li><Link to="/questions">Questions</Link></li>
                <li><Link to="/certificates">Certificates</Link></li>
            </ul>
        </aside>
    );
};

export default Sidebar;
