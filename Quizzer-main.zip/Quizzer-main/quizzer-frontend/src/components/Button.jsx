// src/components/Button.jsx
import React from "react";
import PropTypes from "prop-types";
import classNames from 'classnames';

const Button = ({
    label,
    onClick,
    type = "button",
    variant = "primary",
    size = "md",
    disabled = false,
    icon: Icon,
    fullWidth = false
}) => {
    const baseStyles = "inline-flex items-center justify-center font-medium rounded focus:outline-none transition duration-300 ease-in-out";
    const sizeStyles = {
        sm: "px-3 py-1 text-sm",
        md: "px-4 py-2 text-base",
        lg: "px-6 py-3 text-lg"
    };
    const variantStyles = {
        primary: "bg-purple-600 text-white hover:bg-purple-700 focus:ring-2 focus:ring-purple-500",
        secondary: "bg-gray-600 text-white hover:bg-gray-700 focus:ring-2 focus:ring-gray-500",
        outline: "bg-transparent border border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white focus:ring-2 focus:ring-purple-500",
        danger: "bg-red-600 text-white hover:bg-red-700 focus:ring-2 focus:ring-red-500"
    };
    const disabledStyles = "opacity-50 cursor-not-allowed";

    return (
        <button
            type={type}
            onClick={onClick}
            disabled={disabled}
            className={classNames(
                baseStyles,
                sizeStyles[size],
                variantStyles[variant],
                fullWidth && "w-full",
                disabled && disabledStyles
            )}
        >
            {Icon && <Icon className="mr-2 w-5 h-5" />}
            {label}
        </button>
    );
};

Button.propTypes = {
    label: PropTypes.string.isRequired,
    onClick: PropTypes.func,
    type: PropTypes.oneOf(["button", "submit", "reset"]),
    variant: PropTypes.oneOf(["primary", "secondary", "outline", "danger"]),
    size: PropTypes.oneOf(["sm", "md", "lg"]),
    disabled: PropTypes.bool,
    icon: PropTypes.elementType,
    fullWidth: PropTypes.bool
};

export default Button;
