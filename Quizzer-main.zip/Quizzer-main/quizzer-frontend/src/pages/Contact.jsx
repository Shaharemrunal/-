// src/pages/Contact.jsx
import React from "react";

const Contact = () => {
    return (
        <div className="bg-gray-900 text-white min-h-screen">
            {/* Hero Section */}
            <section className="py-16 px-8 bg-gradient-to-r from-purple-700 to-blue-800">
                <div className="container mx-auto text-center">
                    <h1 className="text-4xl md:text-6xl font-extrabold mb-4">
                        Get in Touch
                    </h1>
                    <p className="text-lg text-gray-300">
                        Have questions? Need help? We'd love to hear from you.
                    </p>
                </div>
            </section>

            {/* Contact Form */}
            <section className="py-16 px-8 bg-gray-800">
                <div className="container mx-auto max-w-4xl bg-gray-700 p-8 rounded-lg shadow-lg">
                    <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
                    <form action="#" method="POST" className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="name" className="block text-gray-400 mb-2">
                                    Name
                                </label>
                                <input
                                    type="text"
                                    id="name"
                                    name="name"
                                    className="w-full p-3 bg-gray-800 text-gray-200 rounded-md focus:ring-2 focus:ring-purple-500"
                                    placeholder="Your Name"
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-gray-400 mb-2">
                                    Email
                                </label>
                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    className="w-full p-3 bg-gray-800 text-gray-200 rounded-md focus:ring-2 focus:ring-purple-500"
                                    placeholder="you@example.com"
                                    required
                                />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="message" className="block text-gray-400 mb-2">
                                Message
                            </label>
                            <textarea
                                id="message"
                                name="message"
                                rows="6"
                                className="w-full p-3 bg-gray-800 text-gray-200 rounded-md focus:ring-2 focus:ring-purple-500"
                                placeholder="Write your message here..."
                                required
                            ></textarea>
                        </div>
                        <button
                            type="submit"
                            className="w-full bg-purple-600 text-white py-3 rounded-md hover:bg-purple-700 transition-all"
                        >
                            Send Message
                        </button>
                    </form>
                </div>
            </section>

            {/* Contact Info */}
            <section className="py-16 px-8 bg-gray-900">
                <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                        <h3 className="text-xl font-bold mb-2">Email</h3>
                        <p className="text-gray-400">support@quizzer.com</p>
                    </div>
                    <div className="text-center">
                        <h3 className="text-xl font-bold mb-2">Phone</h3>
                        <p className="text-gray-400">+1 (234) 567-890</p>
                    </div>
                    <div className="text-center">
                        <h3 className="text-xl font-bold mb-2">Address</h3>
                        <p className="text-gray-400">123 Quizzer Street, Learning City</p>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Contact;
