import Navbar from "../components/Navbar";
import QuizCard from "../components/QuizCard";

const quizzes = [
    { id: 1, title: "Java Basics", description: "Learn the basics of Java", fee: 10 },
    { id: 2, title: "React Fundamentals", description: "Master React.js", fee: 15 },
    { id: 3, title: "React Fundamentals", description: "Master React.js", fee: 8 },
    { id: 4, title: "React Fundamentals", description: "Master React.js", fee: 15 },
    { id: 5, title: "React Fundamentals", description: "Master React.js", fee: 15 },
    { id: 6, title: "React Fundamentals", description: "Master React.js", fee: 15 },
];
 

const Home = () => (
    <div>
        <Navbar />
        <div className="container mx-auto my-8 p-8">
            <h1 className="text-2xl font-bold mb-6">Available Quizzes</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {quizzes.map((quiz) => (
                    <QuizCard
                        key={quiz.id}
                        title={quiz.title}
                        description={quiz.description}
                        fee={quiz.fee}
                        onDetailsClick={() => window.location.href = `/quiz/${quiz.id}`}
                    />
                ))}
            </div>
        </div>
    </div>
);

export default Home;
