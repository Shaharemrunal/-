import React, { useState } from "react";
import Navbar from "../components/Navbar";
import axios from "axios";

const QuizDetails = () => {
    const [amount, setAmount] = useState(350);

    const handlePayment = async () => {
        const data = { amount: amount };
        try {
            const response = await axios.post("http://localhost:5000/api/payment/order", data);
            console.log(response.data);


            const options = {
                key: "rzp_test_RhcGTu5FUkSay7",
                amount: response.data.amount,
                currency: response.data.currency,
                name: "Mass",
                description: "Test Mode",
                order_id: response.data.id,
                handler: async (response) => {
                    console.log("Payment response", response);

                    try {
                        const verifyResponse = await axios.post("http://localhost:5000/api/payment/verify", {
                            razorpay_order_id: response.razorpay_order_id,
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_signature: response.razorpay_signature,
                        });

                        const verifyData = verifyResponse.data;
                        if (verifyData.message) {
                            console.log("Payment verified successfully", verifyData.message);
                        }
                    } catch (error) {
                        console.log("Error during payment verification:", error);
                    }
                },
                theme: {
                    color: "#5f63b8",
                },
            };

            const razorpay = new window.Razorpay(options);
            razorpay.open();

        } catch (error) {
            console.log("Error during payment request:", error);
        }
    };

    return (
        <div>
            <Navbar />
            <div className="container mx-auto my-8">
                <h1 className="text-2xl font-bold mb-6">Quiz Details</h1>
                <p>Description of the quiz will go here...</p>
                <button
                    className="btn bg-purple-600 text-white mt-4"
                    onClick={handlePayment}
                >
                    Unlock Quiz
                </button>
            </div>
        </div>
    );
};

export default QuizDetails;
