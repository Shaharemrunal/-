import React from "react";

const Homepage = () => {
    return (
        <div className="bg-gradient-to-b from-purple-800 via-purple-600 to-purple-500 text-white">
            {/* Navbar */}
            <header className="flex justify-between items-center px-8 py-4 bg-purple-700">
                <h1 className="text-2xl font-bold">Quizzer</h1>
                <nav>
                    <ul className="flex space-x-6">
                        <li><a href="#features" className="hover:underline">Features</a></li>
                        <li><a href="#how-it-works" className="hover:underline">How it Works?</a></li>
                        <li><a href="#about" className="hover:underline">About Us</a></li>
                        <li><button className="bg-purple-900 px-4 py-2 rounded-lg hover:bg-purple-800 transition">Login</button></li>
                    </ul>
                </nav>
            </header>

            {/* Hero Section */}
            <section className="text-center py-12 px-4">
                <h2 className="text-4xl font-bold mb-4">Let’s checkout your learning journey</h2>
                <p className="text-lg mb-8">We help you prepare for exams and quizzes.</p>
                <button className="bg-purple-900 px-6 py-3 rounded-lg hover:bg-purple-800 transition">Start Solving</button>
            </section>

            {/* How it Works Section */}
            <section id="how-it-works" className="py-12 px-8">
                <h3 className="text-3xl font-bold mb-6 text-center">How it Works?</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">1. Choose your subject</h4>
                        <p>From a vast selection of subjects, start your journey.</p>
                    </div>
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">2. Select Difficulty</h4>
                        <p>Get questions tailored to your preferred difficulty.</p>
                    </div>
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">3. Increasing Difficulty</h4>
                        <p>Each question gets tougher, irrespective of the last result.</p>
                    </div>
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">4. Detailed Overview</h4>
                        <p>Get a detailed review of your performance and tips to improve.</p>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section id="features" className="py-12 px-8 bg-purple-800">
                <h3 className="text-3xl font-bold mb-6 text-center">Features</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">3D Coverage</h4>
                        <p>Comprehensive coverage of all questions related to a particular topic.</p>
                    </div>
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">Plenty of Subjects</h4>
                        <p>Choose from subjects like Computer Languages, Engineering, and more.</p>
                    </div>
                    <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                        <h4 className="font-bold text-xl mb-2">Detailed Solutions</h4>
                        <p>Detailed explanations for better understanding of solutions.</p>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Homepage;