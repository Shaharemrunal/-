import React, { useEffect, useState } from "react";
import StatsCard from "../components/StatsCard";
import axiosInstance from "../api/axiosConfig";

const Dashboard = () => {
    const [stats, setStats] = useState({ users: 0, quizzes: 0, certificates: 0 });

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const response = await axiosInstance.get("/admin/stats");
                setStats(response.data.stats);
            } catch (error) {
                console.error("Error fetching stats:", error);
            }
        };

        fetchStats();
    }, []);

    return (
        <div className="dashboard">
            <h2>Dashboard</h2>
            <div className="stats-grid">
                <StatsCard title="Total Users" value={stats.users} />
                <StatsCard title="Total Quizzes" value={stats.quizzes} />
                <StatsCard title="Certificates Issued" value={stats.certificates} />
            </div>
        </div>
    );
};

export default Dashboard;
