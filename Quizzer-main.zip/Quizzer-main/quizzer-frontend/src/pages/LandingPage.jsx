// m// src/pages/LandingPage.jsx
import React from "react";
import Navbar from "../components/Navbar";
import heroImage from "../assets/images/QuizzerImg.png";
import vector_img1 from "../assets/images/home_img1.png";
import vector_img2 from "../assets/images/home_img2.png";
import vector_img3 from "../assets/images/home_img3.png";
import vector_img4 from "../assets/images/home_img4.png";
import profile1 from "../assets/images/profile1.jpg";
import profile2 from "../assets/images/profile2.jpg";
import Button from "../components/Button";

const LandingPage = () => {
    return (
        <div>
            <Navbar />
            <div className="bg-gray-900 text-white p-0">
                <section className="relative bg-gradient-to-r from-purple-700 to-blue-800 py-12 px-8">
                    <div className="container mx-auto flex flex-col lg:flex-row items-center justify-between">
                        <div className="lg:w-1/2">
                            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4">
                                Let’s checkout your learning journey
                            </h1>
                            <p className="text-lg text-gray-300 mb-6">
                                We help you prepare for exams and quizzes.
                            </p>
                            <div className="flex items-center space-x-4 ml-36">
                                <input
                                    type="text"
                                    placeholder="Try Python, React, Java..."
                                    className="p-3 rounded-md w-64 bg-gray-800 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                />
                                <Button label="Start Solving" />
                            </div>
                            <p className="mt-4 text-sm text-gray-400">
                                Trusted by <span className="font-bold text-white">50k+ users</span> with a rating of <span className="font-bold text-white">4.8/5</span>
                            </p>
                        </div>
                        <div className="lg:w-1/2 mt-8 lg:mt-0">
                            <img
                                src={heroImage}
                                alt="Hero Illustration"
                                className="rounded-full"
                            />
                        </div>
                    </div>
                </section>

                <section className="py-16 bg-gray-100">
                    <div className="container mx-auto flex flex-col md:flex-row items-center">
                        {/* Text Content */}
                        <div className="md:w-1/2 px-6">
                            <h1 className="text-4xl font-bold mb-6 text-gray-800">
                                Let’s checkout your learning journey
                            </h1>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                {/* Box 1 */}
                                <div className="flex items-start">
                                    <img src="path/to/vector1.svg" alt="Vector 1" className="w-12 h-12 mr-4" />
                                    <div>
                                        <h2 className="text-xl font-semibold text-gray-700">Quiz Challenges</h2>
                                        <p className="text-gray-600">
                                            Test your knowledge with engaging quizzes across various topics.
                                        </p>
                                    </div>
                                </div>
                                {/* Box 2 */}
                                <div className="flex items-start">
                                    <img src="path/to/vector2.svg" alt="Vector 2" className="w-12 h-12 mr-4" />
                                    <div>
                                        <h2 className="text-xl font-semibold text-gray-700">Track Progress</h2>
                                        <p className="text-gray-600">
                                            Monitor your learning journey and improve over time.
                                        </p>
                                    </div>
                                </div>
                                {/* Box 3 */}
                                <div className="flex items-start">
                                    <img src="path/to/vector3.svg" alt="Vector 3" className="w-12 h-12 mr-4" />
                                    <div>
                                        <h2 className="text-xl font-semibold text-gray-700">Custom Quizzes</h2>
                                        <p className="text-gray-600">
                                            Create your own quizzes tailored to your learning goals.
                                        </p>
                                    </div>
                                </div>
                                {/* Box 4 */}
                                <div className="flex items-start">
                                    <img src="path/to/vector4.svg" alt="Vector 4" className="w-12 h-12 mr-4" />
                                    <div>
                                        <h2 className="text-xl font-semibold text-gray-700">Leaderboard</h2>
                                        <p className="text-gray-600">
                                            Compete with peers and climb the leaderboard.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Image Section */}
                        <div className="md:w-1/2 px-6 mt-8 md:mt-0 flex flex-wrap justify-around">
                            <img
                                src={vector_img1}
                                alt="Learning Journey"
                                className="w-auto rounded-full h-16 mx-auto"
                            />
                            <img
                                src={vector_img2}
                                alt="Learning Journey"
                                className="w-auto rounded-full h-16 mx-auto"
                            />
                            <img
                                src={vector_img3}
                                alt="Learning Journey"
                                className="w-auto rounded-full h-16 mx-auto"
                            />
                            <img
                                src={vector_img4}
                                alt="Learning Journey"
                                className="w-auto rounded-full h-16 mx-auto"
                            />
                        </div>
                    </div>
                </section>

                {/* How it Works Section */}
                <section id="how-it-works" className="py-12 px-8">
                    <h3 className="text-3xl font-bold mb-6 text-center">How it Works?</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                            <h4 className="font-bold text-xl mb-2">1. Choose your subject</h4>
                            <p>From a vast selection of subjects, start your journey.</p>
                        </div>
                        <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                            <h4 className="font-bold text-xl mb-2">2. Select Difficulty</h4>
                            <p>Get questions tailored to your preferred difficulty.</p>
                        </div>
                        <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                            <h4 className="font-bold text-xl mb-2">3. Increasing Difficulty</h4>
                            <p>Each question gets tougher, irrespective of the last result.</p>
                        </div>
                        <div className="p-4 bg-purple-700 rounded-lg hover:scale-105 transition transform">
                            <h4 className="font-bold text-xl mb-2">4. Detailed Overview</h4>
                            <p>Get a detailed review of your performance and tips to improve.</p>
                        </div>
                    </div>
                </section>

                {/* Stats Section */}
                <section className="py-16 bg-gray-800">
                    <div className="container mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
                        {["20+", "30+", "3+", "4.8 ★"].map((stat, index) => (
                            <div key={index}>
                                <h2 className="text-4xl font-extrabold text-white">{stat}</h2>
                                <p className="text-gray-400">
                                    {index === 3 ? "Average Rating" : "Experienced Tutors"}
                                </p>
                            </div>
                        ))}
                    </div>
                </section>

                {/* Featured Section */}
                <section className="py-16 px-8 bg-gray-900">
                    <div className="container mx-auto">
                        <h2 className="text-3xl font-bold mb-8 text-center">
                            Find the right Quiz for You
                        </h2>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                            {[profile1, profile2, profile1, profile2].map((profile, index) => (
                                <div
                                    key={index}
                                    className="bg-gray-800 rounded-lg overflow-hidden shadow-md hover:scale-105 transition transform"
                                >
                                    <img src={profile} alt="Tutor Profile" className="w-full h-40 object-cover" />
                                    <div className="p-4">
                                        <h3 className="text-lg font-semibold">Steve Bose</h3>
                                        <p className="text-sm text-gray-400">UI/UX Designer</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="text-center mt-8">
                            <a href="/tutors" className="text-purple-400 hover:underline">
                                See all tutors →
                            </a>
                        </div>
                    </div>
                </section>

                {/* CTA Section */}
                <section className="py-16 bg-gradient-to-r from-blue-900 to-purple-900 text-center">
                    <h2 className="text-4xl font-bold text-white mb-4">
                        Lessons You’ll Love. Guaranteed.
                    </h2>
                    <p className="text-lg text-gray-300 mb-6">
                        Try another tutor for free if you’re not satisfied.
                    </p>
                    <Button label="Get Started Today" />
                </section>
            </div>
        </div>
    );
};

export default LandingPage;