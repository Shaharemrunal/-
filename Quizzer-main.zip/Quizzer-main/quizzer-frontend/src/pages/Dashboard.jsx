import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import CertificateCard from "../components/CertificateCard";

const certificates = [
    { id: 1, quizTitle: "Java Basics", date: "2024-11-20" },
    { id: 2, quizTitle: "React Fundamentals", date: "2024-11-21" },
];

const Dashboard = () => (
    <div>
        <div className="container mx-auto my-8 p-12">
            <h2 className="text-3xl font-bold mb-6"> Welcome to Dashboard </h2>
            <h4 className="text-2xl mb-6">Your Certificates</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {certificates.map((cert) => (
                    <CertificateCard
                        key={cert.id}
                        quizTitle={cert.quizTitle}
                        date={cert.date}
                        onDownloadClick={() => alert("Certificate downloaded")}
                    />
                ))}
            </div>
        </div>
    </div>
);

export default Dashboard;
