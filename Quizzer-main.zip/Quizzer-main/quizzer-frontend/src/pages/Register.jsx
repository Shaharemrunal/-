import React, { useState } from "react";

const Register = () => {
    const [formData, setFormData] = useState({ name: "", email: "", password: "" });

    const handleRegister = (e) => {
        e.preventDefault();
        console.log(formData);
    };

    return (
        <div className="flex justify-center items-center min-h-screen bg-gray-100">
            <form
                onSubmit={handleRegister}
                className="bg-white shadow-md rounded px-8 py-6 max-w-md w-full"
            >
                <h2 className="text-xl font-bold mb-4">Register</h2>
                <input
                    type="text"
                    className="input mb-4"
                    placeholder="Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
                <input
                    type="email"
                    className="input mb-4"
                    placeholder="Email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
                <input
                    type="password"
                    className="input mb-4"
                    placeholder="Password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
                <button className="btn bg-green-600 text-white w-full">Register</button>
            </form>
        </div>
    );
};

export default Register;
