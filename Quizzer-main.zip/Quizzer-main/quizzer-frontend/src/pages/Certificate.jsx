import React from "react";

const Certificate = () => (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
        <div className="bg-white shadow-md rounded px-8 py-6 max-w-lg w-full text-center">
            <h1 className="text-2xl font-bold mb-4">Congratulations!</h1>
            <p className="text-gray-600 mb-4">You passed the quiz and earned a certificate.</p>
            <button className="btn bg-green-600 text-white w-full">Download Certificate</button>
        </div>
    </div>
);

export default Certificate;
