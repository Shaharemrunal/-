import Certificate from "../models/certificate.models.js";
import User from "../models/user.models.js";
import Quiz from "../models/quiz.models.js";

/* Generate a certificate for a completed quiz */
export const generateCertificate = async (req, res) => {
    try {
        const { quizId } = req.body;
        const userId = req.user.id; // User ID from auth middleware

        // Validate user
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        // Validate quiz
        const quiz = await Quiz.findById(quizId);
        if (!quiz) {
            return res.status(404).json({ error: "Quiz not found" });
        }

        // Check for duplicate certificates
        const existingCertificate = await Certificate.findOne({ userId, quizId });
        if (existingCertificate) {
            return res.status(400).json({ error: "Certificate already exists for this quiz" });
        }

        // Create and save the certificate
        const newCertificate = new Certificate({
            userId,
            quizId,
            quizTitle: quiz.title,
            date: new Date(),
        });
        await newCertificate.save();

        res.status(201).json({
            message: "Certificate generated successfully",
            certificate: newCertificate,
        });
    } catch (error) {
        console.error("Error generating certificate:", error.message);
        res.status(500).json({ error: "Failed to generate certificate" });
    }
};

/* Get all certificates for the authenticated user */
export const getCertificates = async (req, res) => {
    try {
        const userId = req.user.id; // User ID from auth middleware

        // Fetch certificates for the user
        const certificates = await Certificate.find({ userId });
        if (!certificates.length) {
            return res.status(404).json({ error: "No certificates found for this user" });
        }

        res.status(200).json(certificates);
    } catch (error) {
        console.error("Error fetching certificates:", error.message);
        res.status(500).json({ error: "Failed to retrieve certificates" });
    }
};
