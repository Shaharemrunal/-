import jwt from "jsonwebtoken";
import User from "../models/user.models.js";
import Quiz from "../models/quiz.models.js";
import Certificate from "../models/certificate.models.js";

// User management
export const getUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json({ success: true, users });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedUser = await User.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json({ success: true, updatedUser });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const deleteUser = async (req, res) => {
    try {
        const { id } = req.params;
        await User.findByIdAndDelete(id);
        res.status(200).json({ success: true, message: "User deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Quiz management
export const getQuizzes = async (req, res) => {
    try {
        const quizzes = await Quiz.find();
        res.status(200).json({ success: true, quizzes });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const createQuiz = async (req, res) => {
    try {
        const newQuiz = new Quiz(req.body);
        await newQuiz.save();
        res.status(201).json({ success: true, quiz: newQuiz });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const updateQuiz = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedQuiz = await Quiz.findByIdAndUpdate(id, req.body, { new: true });
        res.status(200).json({ success: true, updatedQuiz });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const deleteQuiz = async (req, res) => {
    try {
        const { id } = req.params;
        await Quiz.findByIdAndDelete(id);
        res.status(200).json({ success: true, message: "Quiz deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// System statistics
export const getStats = async (req, res) => {
    try {
        const totalUsers = await User.countDocuments();
        const totalQuizzes = await Quiz.countDocuments();
        const totalCertificates = await Certificate.countDocuments();

        res.status(200).json({
            success: true,
            stats: { totalUsers, totalQuizzes, totalCertificates },
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Admin login handler
export const adminLogin = (req, res) => {
    const { username, password } = req.body;

    // Simple validation for demo purposes
    if (username === "admin" && password === "admin123") {
        const token = jwt.sign({ role: "admin" }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(200).json({
            success: true,
            message: "Admin logged in successfully",
            token,
        });
    }

    res.status(401).json({
        success: false,
        message: "Invalid credentials",
    });
};
