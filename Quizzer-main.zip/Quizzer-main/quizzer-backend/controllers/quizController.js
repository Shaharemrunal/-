import Quiz from "../models/quiz.models.js";

// Create a new quiz
export const createQuiz = async (req, res) => {
    try {
        const { title, duration, questions } = req.body;

        // Validate inputs
        if (!title || !duration || !questions || !Array.isArray(questions) || questions.length === 0) {
            return res.status(400).json({ error: "Title, duration, and valid questions are required" });
        }

        // Validate each question
        const invalidQuestion = questions.find(
            (question) =>
                !question.questionText ||
                !Array.isArray(question.options) ||
                question.options.length !== 4 ||
                question.correctAnswer === undefined
        );
        if (invalidQuestion) {
            return res
                .status(400)
                .json({ error: "Each question must have text, 4 options, and a correct answer" });
        }

        // Create and save the quiz
        const newQuiz = new Quiz({ title, duration, questions });
        await newQuiz.save();

        res.status(201).json({ message: "Quiz created successfully", quiz: newQuiz });
    } catch (error) {
        console.error("Error creating quiz:", error.message);
        res.status(500).json({ error: "Failed to create quiz" });
    }
};

// Get a quiz by ID
export const getQuizById = async (req, res) => {
    try {
        const { id } = req.params;

        // Fetch quiz from the database
        const quiz = await Quiz.findById(id);
        if (!quiz) {
            return res.status(404).json({ error: "Quiz not found" });
        }

        res.status(200).json(quiz);
    } catch (error) {
        console.error("Error fetching quiz:", error.message);
        res.status(500).json({ error: "Failed to retrieve quiz" });
    }
};

// Get all quizzes
export const getAllQuizzes = async (req, res) => {
    try {
        const quizzes = await Quiz.find();

        if (!quizzes.length) {
            return res.status(404).json({ error: "No quizzes available" });
        }

        res.status(200).json({ quizzes });
    } catch (error) {
        console.error("Error fetching quizzes:", error.message);
        res.status(500).json({ error: "Failed to retrieve quizzes" });
    }
};

// Delete a quiz by ID
export const deleteQuiz = async (req, res) => {
    try {
        const { id } = req.params;

        // Delete quiz from the database
        const deletedQuiz = await Quiz.findByIdAndDelete(id);
        if (!deletedQuiz) {
            return res.status(404).json({ error: "Quiz not found" });
        }

        res.status(200).json({ message: "Quiz deleted successfully" });
    } catch (error) {
        console.error("Error deleting quiz:", error.message);
        res.status(500).json({ error: "Failed to delete quiz" });
    }
};
