import express from "express";
import { generateCertificate, getCertificates } from "../controllers/certificateController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// Route to generate a new certificate
router.post("/generate", protect, generateCertificate);

// Route to get certificates for the authenticated user
router.get("/", protect, getCertificates);

export default router;
