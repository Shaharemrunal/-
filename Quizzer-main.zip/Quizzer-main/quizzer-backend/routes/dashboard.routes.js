import express from "express";
import { authMiddleware } from "../middleware/authMiddleware.js";

const router = express.Router();
router.get("/", authMiddleware, (req, res) => {
    res.status(200).json({
        success: true,
        message: "Dashboard analytics fetched successfully",
        data: {
            totalUsers: 100, // Example: Replace with database queries
            totalQuizzes: 25,
            totalCertificates: 75,
        },
    });
});

export default router;
