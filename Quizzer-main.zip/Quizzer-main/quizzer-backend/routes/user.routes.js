import express from "express";
import User from "../models/user.models.js";

const router = express.Router();

// Create a user
router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const user = new User({ name, email, password });
        await user.save();
        res.status(201).json({ success: true, message: "User registered successfully" });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
});

// Fetch all users
router.get("/", async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json(users);
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

export default router;
