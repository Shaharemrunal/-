import express from "express";
import { createOrder, verifyPayment } from "../controllers/rozerPayControler.js";

const router = express.Router();

// Routes
router.post("/order", createOrder);
router.post("/verify", verifyPayment);

export default router;
