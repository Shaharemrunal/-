import express from "express";
import { createQuiz, getQuizById, getAllQuizzes, deleteQuiz } from "../controllers/quizController.js";
import { protect, admin } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/", protect, admin, createQuiz);
router.get("/:id", protect, getQuizById);
router.get("/", protect, getAllQuizzes);
router.delete("/:id", protect, admin, deleteQuiz);

export default router;
