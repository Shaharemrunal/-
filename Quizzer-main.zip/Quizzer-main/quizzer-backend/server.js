// import express from "express";
// import cors from "cors";
// import morgan from "morgan";
// import helmet from "helmet";
// import mongoose from "mongoose";
// import path from "path";
// import { fileURLToPath } from "url";
// import dotenv from "dotenv";
// import bodyParser from "body-parser";
// import authRoutes from "./routes/auth.routes.js";
// import quizRoutes from "./routes/quiz.routes.js";
// import certificateRoutes from "./routes/certificate.routes.js";
// import dashboardRoutes from "./routes/dashboard.routes.js";
// import adminRoutes from "./routes/admin.routes.js";
// import payment from './routes/payment.js'
// dotenv.config();

// const app = express();
// const __dirname = path.dirname(fileURLToPath(import.meta.url));
// // /quizzerDB?retryWrites=true&w=majority&appName=Cluster0
// // MongoDB Connection with Recommended Syntax
// const connectDB = async (retries = 5, delay = 5000) => {
//     while (retries) {
//         try {
//             const uri = process.env.MONGO_URI;
//             const clientOptions = {
//                 serverApi: {
//                     version: "1",
//                     strict: true,
//                     deprecationErrors: true
//                 }
//             };

//             const connectionInstance = await mongoose.connect(uri, clientOptions);
//             console.log(`MongoDB Connected! DB HOST: ${connectionInstance.connection.host}`);
//             return; // Exit once connected
//         } catch (error) {
//             console.error(`MongoDB connection failed. Retries left: ${retries - 1}`);
//             console.error("Error details:", error.message);

//             if (error.code === "ENOTFOUND" || error.syscall === "querySrv") {
//                 console.error(
//                     "Ensure the connection string is correct and includes `retryWrites=true&w=majority`."
//                 );
//             }

//             retries -= 1;
//             if (retries === 0) {
//                 console.error("Exhausted all retries. Exiting.");
//                 process.exit(1);
//             }

//             // Wait for a specified delay before retrying
//             await new Promise((resolve) => setTimeout(resolve, delay));
//         }
//     }
// };

// //Call the connectDB function to establish the connection
// connectDB();






// // Middleware configuration
// app.use(cors({
//     origin: process.env.CORS_ORIGIN || [
//         'http://localhost:5173',
//         'http://localhost:5000',
//         'https://quizzer.vercel.app',
//     ],
//     methods: ['GET', 'POST', 'PUT', 'DELETE'],
//     credentials: true,
// }));
// app.use(helmet());
// app.use(morgan("dev"));
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));

// // API routes
// app.use("/api/auth", authRoutes);
// app.use("/api/quizzes", quizRoutes);
// app.use("/api/certificates", certificateRoutes);
// app.use("/api/dashboard", dashboardRoutes);
// app.use("/api/admin", adminRoutes);

// // Serve static files in production
// if (process.env.NODE_ENV === "production") {
//     const clientBuildPath = path.join(__dirname, "client", "build");
//     app.use(express.static(clientBuildPath));
//     app.get("*", (req, res) => {
//         res.sendFile(path.resolve(clientBuildPath, "index.html"));
//     });
// }

// // Error handling middleware
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(err.status || 500).json({
//         success: false,
//         message: err.message || "Internal Server Error",
//     });
// });

// app.get('/', (req, res) => {
//     res.send('Razorpay Payment Gateway Using React And Node Js ')
// })
// app.use('/api/payment', payment);

// // Start the server
// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//     console.log(`Server running on http://localhost:${PORT}`);
// });

// export default app;


import express from "express";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import mongoose from "mongoose";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import authRoutes from "./routes/auth.routes.js";
import quizRoutes from "./routes/quiz.routes.js";
import certificateRoutes from "./routes/certificate.routes.js";
import dashboardRoutes from "./routes/dashboard.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import payment from "./routes/payment.js";

dotenv.config();

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// MongoDB Connection
const connectDB = async () => {
    try {
        const uri = process.env.MONGO_URI;
        const connectionInstance = await mongoose.connect(uri, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log(`MongoDB Connected! DB HOST: ${connectionInstance.connection.host}`);
    } catch (error) {
        console.error("MongoDB connection failed:", error.message);
        process.exit(1);
    }
};
connectDB();

// Middleware configuration
// app.use(cors({
//     origin: process.env.CORS_ORIGIN || ["http://localhost:5173", "https://quizzer.vercel.app"],
//     methods: ["GET", "POST", "PUT", "DELETE"],
//     credentials: true,
// }));

app.use(cors({
    origin: (origin, callback) => {
        const allowedOrigins = ['http://localhost:5173', 'https://quizzer.vercel.app'];
        if (allowedOrigins.includes(origin)) {
            callback(null, true); // Allow the request
        } else {
            callback(new Error('Not allowed by CORS')); // Reject the request
        }
    },
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true, 
}));

app.use(helmet());
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/quizzes", quizRoutes);
app.use("/api/certificates", certificateRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/payment", payment);

// Serve static files in production
if (process.env.NODE_ENV === "production") {
    const clientBuildPath = path.join(__dirname, "client", "build");
    app.use(express.static(clientBuildPath));
    app.get("*", (req, res) => {
        res.sendFile(path.resolve(clientBuildPath, "index.html"));
    });
}

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(err.status || 500).json({
        success: false,
        message: err.message || "Internal Server Error",
    });
});



const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

export default app;

