import mongoose from "mongoose";

const certificateSchema = new mongoose.Schema(
    {
        user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
        quiz: { type: mongoose.Schema.Types.ObjectId, ref: "Quiz", required: true },
        date: { type: Date, default: Date.now },
    },
    { timestamps: true }
);

const Certificate = mongoose.model("Certificate", certificateSchema);
export default Certificate;
