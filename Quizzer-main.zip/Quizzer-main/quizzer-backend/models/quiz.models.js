import mongoose from "mongoose";

const questionSchema = new mongoose.Schema({
    questionText: { type: String, required: true },
    options: { type: [String], required: true },
    correctAnswer: { type: Number, required: true },
});

const quizSchema = new mongoose.Schema(
    {
        title: { type: String, required: true },
        description: { type: String },
        questions: [questionSchema], // Embed questions as a sub-schema
        fee: { type: Number, required: true },
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // Organizer/admin reference
    },
    { timestamps: true }
);

const Quiz = mongoose.model("Quiz", quizSchema);
export default Quiz;
